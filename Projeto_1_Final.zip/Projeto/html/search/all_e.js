var searchData=
[
  ['ver_5finterseçoes_0',['ver_interseçoes',['../_projeto1_8c.html#af922e3bd41debf85680aed76e16f9aec',1,'ver_interseçoes(Frequencia *lista, char tipoA, char tipoB):&#160;Projeto1.c'],['../_projeto1_8h.html#af922e3bd41debf85680aed76e16f9aec',1,'ver_interseçoes(Frequencia *lista, char tipoA, char tipoB):&#160;Projeto1.c']]],
  ['vertice_5fexiste_1',['vertice_existe',['../_projeto1_8c.html#a9e17aa6a273bbe60a1e45a564b5a4f93',1,'vertice_existe(Frequencia *listasfreq, int vertice):&#160;Projeto1.c'],['../_projeto1_8h.html#a9e17aa6a273bbe60a1e45a564b5a4f93',1,'vertice_existe(Frequencia *listasfreq, int vertice):&#160;Projeto1.c']]]
];
