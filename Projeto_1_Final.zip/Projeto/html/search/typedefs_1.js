var searchData=
[
  ['frequencia_0',['Frequencia',['../_projeto1_8h.html#acc31bb3e81a0e6c19c075524c9e95f95',1,'Projeto1.h']]]
];
