var searchData=
[
  ['adicionar_5fantena_0',['adicionar_antena',['../_projeto1_8c.html#a6071abf4ba9d2e4b76bb7ff8692cbcde',1,'adicionar_antena(Antena **antena, char ***matriz, int *linhas, int *colunas, char freq, int x, int y):&#160;Projeto1.c'],['../_projeto1_8h.html#a6071abf4ba9d2e4b76bb7ff8692cbcde',1,'adicionar_antena(Antena **antena, char ***matriz, int *linhas, int *colunas, char freq, int x, int y):&#160;Projeto1.c']]],
  ['adjacente_1',['Adjacente',['../struct_adjacente.html',1,'Adjacente'],['../_projeto1_8h.html#aaf8d838b51951d29be56e29a7721ee83',1,'Adjacente:&#160;Projeto1.h']]],
  ['antena_2',['Antena',['../struct_antena.html',1,'Antena'],['../_projeto1_8h.html#a843ab8b81393e8ebb3eb6b76e349acc2',1,'Antena:&#160;Projeto1.h']]],
  ['antena_5fexiste_3',['antena_existe',['../_projeto1_8c.html#a7239bd19f9ab6b230a9d98d402b33881',1,'antena_existe(Antena *antena, int x, int y):&#160;Projeto1.c'],['../_projeto1_8h.html#a7239bd19f9ab6b230a9d98d402b33881',1,'antena_existe(Antena *antena, int x, int y):&#160;Projeto1.c']]],
  ['aplicar_5fnefasto_4',['aplicar_nefasto',['../_projeto1_8c.html#a04a4ee78374a0ed17a68d4d9656c5286',1,'aplicar_nefasto(Antena *antena, int linhas, int colunas, Nefasto **lista):&#160;Projeto1.c'],['../_projeto1_8h.html#a04a4ee78374a0ed17a68d4d9656c5286',1,'aplicar_nefasto(Antena *antena, int linhas, int colunas, Nefasto **lista):&#160;Projeto1.c']]]
];
