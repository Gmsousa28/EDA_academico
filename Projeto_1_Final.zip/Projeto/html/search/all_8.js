var searchData=
[
  ['main_0',['main',['../_projetomain1_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'Projetomain1.c']]],
  ['mesma_5ffrequencia_1',['mesma_frequencia',['../_projeto1_8c.html#a3f26881dc7b40cf8c67a7bb797af517b',1,'mesma_frequencia(Frequencia *listasfreq, int v1, int v2):&#160;Projeto1.c'],['../_projeto1_8h.html#a3f26881dc7b40cf8c67a7bb797af517b',1,'mesma_frequencia(Frequencia *listasfreq, int v1, int v2):&#160;Projeto1.c']]]
];
