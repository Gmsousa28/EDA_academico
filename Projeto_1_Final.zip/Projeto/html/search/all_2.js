var searchData=
[
  ['calcular_5fcaminhos_0',['calcular_caminhos',['../_projeto1_8c.html#ad2ac7066bdda579a2518e9c7ef701874',1,'calcular_caminhos(Grafo *atual, int destino, int visitado[], int caminho[], int pos, Frequencia *listasfreq):&#160;Projeto1.c'],['../_projeto1_8h.html#ad2ac7066bdda579a2518e9c7ef701874',1,'calcular_caminhos(Grafo *atual, int destino, int visitado[], int caminho[], int pos, Frequencia *listasfreq):&#160;Projeto1.c']]],
  ['criar_5fantena_1',['criar_antena',['../_projeto1_8c.html#a4890f8d208bdbda0ea801ac700820c3d',1,'Projeto1.c']]],
  ['criarll_5fadjacentes_2',['criarLL_adjacentes',['../_projeto1_8c.html#a18c2c58394d4fa02268badafc65cce78',1,'criarLL_adjacentes(Frequencia *listafreq):&#160;Projeto1.c'],['../_projeto1_8h.html#a18c2c58394d4fa02268badafc65cce78',1,'criarLL_adjacentes(Frequencia *listafreq):&#160;Projeto1.c']]],
  ['cruzar_5fsegmentos_3',['cruzar_segmentos',['../_projeto1_8c.html#a3a9a360194b88b9e47b1c5978fa2a128',1,'cruzar_segmentos(int x1, int y1, int x2, int y2, int x3, int y3, int x4, int y4, float *ix, float *iy):&#160;Projeto1.c'],['../_projeto1_8h.html#a3a9a360194b88b9e47b1c5978fa2a128',1,'cruzar_segmentos(int x1, int y1, int x2, int y2, int x3, int y3, int x4, int y4, float *ix, float *iy):&#160;Projeto1.c']]]
];
