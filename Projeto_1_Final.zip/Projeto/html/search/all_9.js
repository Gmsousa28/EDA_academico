var searchData=
[
  ['nefasto_0',['Nefasto',['../struct_nefasto.html',1,'Nefasto'],['../_projeto1_8h.html#ae690a2a29c460c7055653d2f38d277d4',1,'Nefasto:&#160;Projeto1.h']]]
];
