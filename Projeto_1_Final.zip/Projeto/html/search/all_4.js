var searchData=
[
  ['free_5flista1_0',['free_lista1',['../_projeto1_8c.html#a79ed2988f79ed942c3454e74255a4ff7',1,'free_lista1(Antena *antena):&#160;Projeto1.c'],['../_projeto1_8h.html#a79ed2988f79ed942c3454e74255a4ff7',1,'free_lista1(Antena *antena):&#160;Projeto1.c']]],
  ['free_5flista2_1',['free_lista2',['../_projeto1_8c.html#ad8f6a041b5527a1c09783828892f2a82',1,'free_lista2(Nefasto *lista):&#160;Projeto1.c'],['../_projeto1_8h.html#ad8f6a041b5527a1c09783828892f2a82',1,'free_lista2(Nefasto *lista):&#160;Projeto1.c']]],
  ['free_5flista_5fadj_2',['free_lista_adj',['../_projeto1_8c.html#ae9f2f463b6b6bfbe680e092bc4157c59',1,'free_lista_adj(Adjacente *listaadj):&#160;Projeto1.c'],['../_projeto1_8h.html#ae9f2f463b6b6bfbe680e092bc4157c59',1,'free_lista_adj(Adjacente *listaadj):&#160;Projeto1.c']]],
  ['free_5flista_5ffreq_3',['free_lista_freq',['../_projeto1_8c.html#a0f66eade9aa65db163dce65888aa6ec3',1,'free_lista_freq(Frequencia *listafreq):&#160;Projeto1.c'],['../_projeto1_8h.html#a0f66eade9aa65db163dce65888aa6ec3',1,'free_lista_freq(Frequencia *listafreq):&#160;Projeto1.c']]],
  ['free_5fmatriz_4',['free_matriz',['../_projeto1_8c.html#a64f957347e04d652516c66aa5d10fdfd',1,'free_matriz(char **matriz, int linhas):&#160;Projeto1.c'],['../_projeto1_8h.html#a64f957347e04d652516c66aa5d10fdfd',1,'free_matriz(char **matriz, int linhas):&#160;Projeto1.c']]],
  ['free_5fmatriznefasto_5',['free_matriznefasto',['../_projeto1_8c.html#a4aff91bee90beb816269f52f6e33e313',1,'free_matriznefasto(char **matriz, int linhas, int colunas):&#160;Projeto1.c'],['../_projeto1_8h.html#a4aff91bee90beb816269f52f6e33e313',1,'free_matriznefasto(char **matriz, int linhas, int colunas):&#160;Projeto1.c']]],
  ['frequencia_6',['Frequencia',['../struct_frequencia.html',1,'Frequencia'],['../_projeto1_8h.html#acc31bb3e81a0e6c19c075524c9e95f95',1,'Frequencia:&#160;Projeto1.h']]],
  ['frequencia_5fexiste_7',['frequencia_existe',['../_projeto1_8c.html#a4c4e012804d9b19ccf523c1b3666593f',1,'frequencia_existe(Frequencia *listasfreq, char freq):&#160;Projeto1.c'],['../_projeto1_8h.html#a4c4e012804d9b19ccf523c1b3666593f',1,'frequencia_existe(Frequencia *listasfreq, char freq):&#160;Projeto1.c']]]
];
