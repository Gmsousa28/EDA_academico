var searchData=
[
  ['existe_5fnefasto_0',['existe_nefasto',['../_projeto1_8c.html#acaeeb311ae20df59bff1c1f135b8b31f',1,'existe_nefasto(Nefasto *lista, int x, int y):&#160;Projeto1.c'],['../_projeto1_8h.html#acaeeb311ae20df59bff1c1f135b8b31f',1,'existe_nefasto(Nefasto *lista, int x, int y):&#160;Projeto1.c']]]
];
