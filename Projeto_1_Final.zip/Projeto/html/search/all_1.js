var searchData=
[
  ['busca_5fem_5flargura_0',['busca_em_largura',['../_projeto1_8c.html#a044f1030c84332aebb798462b98c26ef',1,'busca_em_largura(Frequencia *listaFreq, int inicio):&#160;Projeto1.c'],['../_projeto1_8h.html#a525f55821deeabae0c145e95e70ebf2c',1,'busca_em_largura(Frequencia *listasfreq, int inicio):&#160;Projeto1.c']]]
];
