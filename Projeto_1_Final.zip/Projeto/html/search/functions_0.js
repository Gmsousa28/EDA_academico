var searchData=
[
  ['adicionar_5fantena_0',['adicionar_antena',['../_projeto1_8c.html#a6071abf4ba9d2e4b76bb7ff8692cbcde',1,'adicionar_antena(Antena **antena, char ***matriz, int *linhas, int *colunas, char freq, int x, int y):&#160;Projeto1.c'],['../_projeto1_8h.html#a6071abf4ba9d2e4b76bb7ff8692cbcde',1,'adicionar_antena(Antena **antena, char ***matriz, int *linhas, int *colunas, char freq, int x, int y):&#160;Projeto1.c']]],
  ['antena_5fexiste_1',['antena_existe',['../_projeto1_8c.html#a7239bd19f9ab6b230a9d98d402b33881',1,'antena_existe(Antena *antena, int x, int y):&#160;Projeto1.c'],['../_projeto1_8h.html#a7239bd19f9ab6b230a9d98d402b33881',1,'antena_existe(Antena *antena, int x, int y):&#160;Projeto1.c']]],
  ['aplicar_5fnefasto_2',['aplicar_nefasto',['../_projeto1_8c.html#a04a4ee78374a0ed17a68d4d9656c5286',1,'aplicar_nefasto(Antena *antena, int linhas, int colunas, Nefasto **lista):&#160;Projeto1.c'],['../_projeto1_8h.html#a04a4ee78374a0ed17a68d4d9656c5286',1,'aplicar_nefasto(Antena *antena, int linhas, int colunas, Nefasto **lista):&#160;Projeto1.c']]]
];
