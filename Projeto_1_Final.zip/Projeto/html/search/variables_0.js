var searchData=
[
  ['next_0',['next',['../struct_antena.html#ae518c9afee14b875ac030364762e23ba',1,'Antena::next'],['../struct_nefasto.html#a79b380a65140a7490b4a2bf6d2d52506',1,'Nefasto::next']]]
];
