var searchData=
[
  ['separar_5fpor_5ffrequencia_0',['separar_por_frequencia',['../_projeto1_8c.html#a2b6a14d53965aa126a2313ee71b64746',1,'separar_por_frequencia(Antena *listaAntena, Frequencia **listafreq):&#160;Projeto1.c'],['../_projeto1_8h.html#a2b6a14d53965aa126a2313ee71b64746',1,'separar_por_frequencia(Antena *listaAntena, Frequencia **listafreq):&#160;Projeto1.c']]]
];
