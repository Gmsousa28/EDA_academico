var searchData=
[
  ['frequencia_0',['Frequencia',['../struct_frequencia.html',1,'']]]
];
