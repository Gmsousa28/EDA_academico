var searchData=
[
  ['obter_5ffrequencia_0',['obter_frequencia',['../_projeto1_8c.html#a1975307f2614ff55f83641dd136e0725',1,'obter_frequencia(Frequencia *listasfreq, char freq):&#160;Projeto1.c'],['../_projeto1_8h.html#a1975307f2614ff55f83641dd136e0725',1,'obter_frequencia(Frequencia *listasfreq, char freq):&#160;Projeto1.c']]],
  ['obter_5fvertice_1',['obter_vertice',['../_projeto1_8c.html#a1058d64411ce24800021b64a0fed3e5e',1,'obter_vertice(Frequencia *listasfreq, int vertice):&#160;Projeto1.c'],['../_projeto1_8h.html#a1058d64411ce24800021b64a0fed3e5e',1,'obter_vertice(Frequencia *listasfreq, int vertice):&#160;Projeto1.c']]]
];
