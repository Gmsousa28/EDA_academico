var searchData=
[
  ['iniciar_5fprofundidade_0',['iniciar_profundidade',['../_projeto1_8c.html#a48e2715042cf8171cf6f686975bd07f4',1,'iniciar_profundidade(Frequencia *listasfreq, int vertice_inicial, int *visitado, int num_vertices):&#160;Projeto1.c'],['../_projeto1_8h.html#a48e2715042cf8171cf6f686975bd07f4',1,'iniciar_profundidade(Frequencia *listasfreq, int vertice_inicial, int *visitado, int num_vertices):&#160;Projeto1.c']]]
];
