var searchData=
[
  ['ler_5fficheiro_0',['ler_ficheiro',['../_projeto1_8c.html#a7bb54edc0199fa0de7b3893609c1df59',1,'ler_ficheiro(char *filename, char ***matriz, int *linhas, int *colunas):&#160;Projeto1.c'],['../_projeto1_8h.html#a7bb54edc0199fa0de7b3893609c1df59',1,'ler_ficheiro(char *filename, char ***matriz, int *linhas, int *colunas):&#160;Projeto1.c']]]
];
