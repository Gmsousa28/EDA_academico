var searchData=
[
  ['adjacente_0',['Adjacente',['../struct_adjacente.html',1,'']]],
  ['antena_1',['Antena',['../struct_antena.html',1,'']]]
];
