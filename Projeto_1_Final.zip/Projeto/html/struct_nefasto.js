var struct_nefasto =
[
    [ "next", "struct_nefasto.html#a79b380a65140a7490b4a2bf6d2d52506", null ]
];