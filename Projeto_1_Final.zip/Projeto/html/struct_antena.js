var struct_antena =
[
    [ "next", "struct_antena.html#ae518c9afee14b875ac030364762e23ba", null ],
    [ "x", "struct_antena.html#a3b196deb45a500d432ef7f7a653adbaf", null ]
];