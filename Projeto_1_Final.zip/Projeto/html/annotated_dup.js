var annotated_dup =
[
    [ "Adjacente", "struct_adjacente.html", null ],
    [ "Antena", "struct_antena.html", null ],
    [ "Frequencia", "struct_frequencia.html", null ],
    [ "Grafo", "struct_grafo.html", null ],
    [ "Nefasto", "struct_nefasto.html", null ]
];