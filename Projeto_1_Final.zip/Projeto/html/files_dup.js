var files_dup =
[
    [ "Projeto1.c", "_projeto1_8c.html", "_projeto1_8c" ],
    [ "Projeto1.h", "_projeto1_8h.html", "_projeto1_8h" ],
    [ "Projetomain1.c", "_projetomain1_8c.html", "_projetomain1_8c" ]
];